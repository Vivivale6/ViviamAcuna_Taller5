import numpy as np
import matplotlib.pyplot as plt
import glob
import imageio


a= np.loadtxt("a.txt")
n= np.shape(a)[0]-1
i=1
nombres =[]

while i <= n:
	x = a[:,0]
	y = a [:,1]

	plt.plot(x,y)
	
	nombres.append(nombres)
	plt.savefig("g1.png")

imagenes = []
for nombre in nombres:
	imagenes.append(imageio.imread(nombre))

imageio.mimsave("animacion.gif", imagenes, duration = 0.2)